import { useState } from "react";

const LANGS = {
  fr: {
    flag: "🇫🇷", name: "Français",
    tagline: "Envoyez, Suivez, Recevez",
    subtitle: "Transport Europe ↔ Mali",
    searchFrom: "Départ (Europe)",
    searchTo: "Arrivée (Mali)",
    searchBtn: "Rechercher",
    trackTitle: "Suivi Colis Express",
    trackPlaceholder: "Entrez votre code (ex: #MC-5580)",
    trackBtn: "Suivre",
    urgentTitle: "Départs Urgents",
    sponsored: "Sponsorisé",
    navHome: "Accueil",
    navSearch: "Rechercher",
    navNotif: "Alertes",
    navActivity: "Activité",
    from: "De",
    to: "Vers",
    perKg: "/ kg",
    seeProfile: "Voir le profil",
    step1: "Réceptionné au dépôt",
    step2: "En transit (en mer)",
    step3: "Aux douanes",
    step4: "Prêt au retrait",
    trackResult: "Statut de votre colis",
    close: "Fermer",
    notifTitle: "Notifications",
    notifEmpty: "Aucune notification",
    actTitle: "Mon Activité",
    actEmpty: "Aucune activité récente",
    searchTitle: "Recherche Avancée",
    cities_eu: ["Paris", "Milan", "Madrid", "Bruxelles", "Lyon", "Rome"],
    cities_ml: ["Bamako", "Kayes", "Ségou", "Sikasso", "Mopti", "Gao"],
  },
  it: {
    flag: "🇮🇹", name: "Italiano",
    tagline: "Spedisci, Traccia, Ricevi",
    subtitle: "Trasporto Europa ↔ Mali",
    searchFrom: "Partenza (Europa)",
    searchTo: "Arrivo (Mali)",
    searchBtn: "Cerca",
    trackTitle: "Tracciamento Espresso",
    trackPlaceholder: "Inserisci codice (es: #MC-5580)",
    trackBtn: "Traccia",
    urgentTitle: "Partenze Urgenti",
    sponsored: "Sponsorizzato",
    navHome: "Home",
    navSearch: "Cerca",
    navNotif: "Avvisi",
    navActivity: "Attività",
    from: "Da",
    to: "A",
    perKg: "/ kg",
    seeProfile: "Vedi profilo",
    step1: "Ricevuto al deposito",
    step2: "In transito (mare)",
    step3: "Alla dogana",
    step4: "Pronto al ritiro",
    trackResult: "Stato del tuo pacco",
    close: "Chiudi",
    notifTitle: "Notifiche",
    notifEmpty: "Nessuna notifica",
    actTitle: "La mia Attività",
    actEmpty: "Nessuna attività recente",
    searchTitle: "Ricerca Avanzata",
    cities_eu: ["Milano", "Roma", "Torino", "Napoli", "Parigi", "Madrid"],
    cities_ml: ["Bamako", "Kayes", "Ségou", "Sikasso", "Mopti", "Gao"],
  },
  es: {
    flag: "🇪🇸", name: "Español",
    tagline: "Envía, Rastrea, Recibe",
    subtitle: "Transporte Europa ↔ Mali",
    searchFrom: "Salida (Europa)",
    searchTo: "Llegada (Mali)",
    searchBtn: "Buscar",
    trackTitle: "Rastreo Express",
    trackPlaceholder: "Introduce tu código (ej: #MC-5580)",
    trackBtn: "Rastrear",
    urgentTitle: "Salidas Urgentes",
    sponsored: "Patrocinado",
    navHome: "Inicio",
    navSearch: "Buscar",
    navNotif: "Alertas",
    navActivity: "Actividad",
    from: "De",
    to: "A",
    perKg: "/ kg",
    seeProfile: "Ver perfil",
    step1: "Recibido en depósito",
    step2: "En tránsito (mar)",
    step3: "En aduana",
    step4: "Listo para retirar",
    trackResult: "Estado de tu paquete",
    close: "Cerrar",
    notifTitle: "Notificaciones",
    notifEmpty: "Sin notificaciones",
    actTitle: "Mi Actividad",
    actEmpty: "Sin actividad reciente",
    searchTitle: "Búsqueda Avanzada",
    cities_eu: ["Madrid", "Barcelona", "Paris", "Milano", "Bruxelles", "Lyon"],
    cities_ml: ["Bamako", "Kayes", "Ségou", "Sikasso", "Mopti", "Gao"],
  },
  bm: {
    flag: "🇲🇱", name: "Bamanankan",
    tagline: "Ci, Sɔrɔ, Minɛ",
    subtitle: "Baarakɛcogo Eropa ↔ Mali",
    searchFrom: "Bɔli (Eropa)",
    searchTo: "Sigi (Mali)",
    searchBtn: "Ɲini",
    trackTitle: "Coli Lajɛ Joona",
    trackPlaceholder: "I ka kodi sɛbɛn (misali: #MC-5580)",
    trackBtn: "Lajɛ",
    urgentTitle: "TaamaShɛrɛ Joona",
    sponsored: "Sarali",
    navHome: "So",
    navSearch: "Ɲini",
    navNotif: "Kunnafoni",
    navActivity: "Baara",
    from: "Ka Bɔ",
    to: "Ka Taa",
    perKg: "/ kg",
    seeProfile: "Filisi",
    step1: "Sɔrɔla depot la",
    step2: "Taamaɲɔgɔn (gɛn)",
    step3: "Gudɔn",
    step4: "Ɲɛnajɛli kɛ",
    trackResult: "I ka coli hali",
    close: "Tigɛ",
    notifTitle: "Kunnafoniw",
    notifEmpty: "Kunnafoni tɛ",
    actTitle: "N ka Baara",
    actEmpty: "Baara kura tɛ",
    searchTitle: "Ɲini Kojugu",
    cities_eu: ["Paris", "Milan", "Madrid", "Bruxelles", "Lyon", "Rome"],
    cities_ml: ["Bamako", "Kɛyɛs", "Sɛgu", "Sikaso", "Mopti", "Gao"],
  },
  sn: {
    flag: "🇲🇱", name: "Soninkanxanne",
    tagline: "Yiri, Wori, Sefe",
    subtitle: "Taaxu Eropa ↔ Mali",
    searchFrom: "Tunka (Eropa)",
    searchTo: "Sigi (Mali)",
    searchBtn: "Soxo",
    trackTitle: "Coli Wori Yaaxi",
    trackPlaceholder: "I kodi sebe (misaali: #MC-5580)",
    trackBtn: "Wori",
    urgentTitle: "Taaxu Yaaxi",
    sponsored: "Saraxale",
    navHome: "Gure",
    navSearch: "Soxo",
    navNotif: "Xabaare",
    navActivity: "Baane",
    from: "Ka",
    to: "Ma",
    perKg: "/ kg",
    seeProfile: "Xa fillo",
    step1: "Sefene depot",
    step2: "Taaxun (gerenme)",
    step3: "Gudaane",
    step4: "Hande sefe",
    trackResult: "I coli hali",
    close: "Daga",
    notifTitle: "Xabaare",
    notifEmpty: "Xabaare man na",
    actTitle: "N Baane",
    actEmpty: "Baane fanyi man na",
    searchTitle: "Soxo Gbeyen",
    cities_eu: ["Paris", "Milan", "Madrid", "Bruxelles", "Lyon", "Rome"],
    cities_ml: ["Bamako", "Kayes", "Ségou", "Sikasso", "Mopti", "Gao"],
  },
};

const TRANSPORTERS = [
  {
    id: 1, name: "Mali Express Cargo", rating: 4.8, reviews: 312,
    from: "Paris", to: "Bamako", price: "3.50", nextDep: "15 Juin",
    sponsored: true, emoji: "🚢", color: "#14532d",
    services: ["📦 Cartons", "📺 TV", "🏍️ Motos"],
  },
  {
    id: 2, name: "Sahel Fret Milano", rating: 4.6, reviews: 189,
    from: "Milan", to: "Bamako / Kayes", price: "4.20", nextDep: "18 Juin",
    sponsored: true, emoji: "✈️", color: "#713f12",
    services: ["📦 Cartons", "💻 Électronique"],
  },
  {
    id: 3, name: "Trans-Sahel Madrid", rating: 4.5, reviews: 97,
    from: "Madrid", to: "Bamako", price: "3.80", nextDep: "22 Juin",
    sponsored: false, emoji: "🚢", color: "#1e3a5f",
    services: ["📦 Cartons", "🏍️ Motos", "🛋️ Meubles"],
  },
  {
    id: 4, name: "Bruxelles-Mali Direct", rating: 4.7, reviews: 224,
    from: "Bruxelles", to: "Bamako / Ségou", price: "3.90", nextDep: "25 Juin",
    sponsored: false, emoji: "🚢", color: "#4a044e",
    services: ["📦 Cartons", "📺 TV", "🛒 Divers"],
  },
];

const TRACK_DATA = {
  "#MC-5580": { step: 2, transporter: "Mali Express Cargo", from: "Paris", to: "Bamako", date: "10 Juin 2025", weight: "45 kg" },
  "#MC-1234": { step: 4, transporter: "Sahel Fret Milano", from: "Milan", to: "Kayes", date: "2 Juin 2025", weight: "12 kg" },
  "#MC-9999": { step: 1, transporter: "Trans-Sahel Madrid", from: "Madrid", to: "Bamako", date: "12 Juin 2025", weight: "30 kg" },
};

function speak(text) {
  if ("speechSynthesis" in window) {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    window.speechSynthesis.speak(u);
  }
}

function VoiceBtn({ text, small }) {
  return (
    <button
      onClick={(e) => { e.stopPropagation(); speak(text); }}
      className={`inline-flex items-center justify-center rounded-full bg-yellow-400 hover:bg-yellow-300 text-green-900 transition-all active:scale-95 shadow ${small ? "w-5 h-5 ml-1" : "w-7 h-7 ml-2"}`}
      title="Écouter"
    >
      <span style={{ fontSize: small ? 9 : 12 }}>🔊</span>
    </button>
  );
}

function StepBar({ step, t }) {
  const steps = [t.step1, t.step2, t.step3, t.step4];
  const icons = ["📥", "🚢", "🏛️", "✅"];
  return (
    <div className="mt-4">
      <div className="flex items-center justify-between mb-2">
        {steps.map((s, i) => (
          <div key={i} className="flex flex-col items-center flex-1">
            <div className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold border-2 transition-all ${i + 1 <= step ? "bg-green-600 border-green-600 text-white shadow-lg" : "bg-gray-100 border-gray-300 text-gray-400"}`}>
              {icons[i]}
            </div>
            {i < 3 && (
              <div className="absolute" style={{ display: "none" }} />
            )}
          </div>
        ))}
      </div>
      <div className="relative h-2 bg-gray-200 rounded-full mx-4 mb-3">
        <div className="h-2 bg-green-600 rounded-full transition-all" style={{ width: `${((step - 1) / 3) * 100}%` }} />
      </div>
      <div className="flex justify-between px-1">
        {steps.map((s, i) => (
          <div key={i} className={`text-center flex-1 px-0.5`}>
            <p className={`text-xs leading-tight ${i + 1 <= step ? "text-green-700 font-semibold" : "text-gray-400"}`}>{s}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function MonColis() {
  const [lang, setLang] = useState("fr");
  const [activeTab, setActiveTab] = useState("home");
  const [trackCode, setTrackCode] = useState("");
  const [trackResult, setTrackResult] = useState(null);
  const [trackError, setTrackError] = useState(false);
  const [showTrackModal, setShowTrackModal] = useState(false);
  const [searchFrom, setSearchFrom] = useState("");
  const [searchTo, setSearchTo] = useState("");
  const [searchResults, setSearchResults] = useState(null);
  const [selectedTransporter, setSelectedTransporter] = useState(null);
  const [carouselIndex, setCarouselIndex] = useState(0);
  const [showLangPicker, setShowLangPicker] = useState(false);

  const t = LANGS[lang];
  const sponsored = TRANSPORTERS.filter(x => x.sponsored);
  const all = TRANSPORTERS;

  function doTrack() {
    const code = trackCode.trim().toUpperCase();
    const found = TRACK_DATA[code] || TRACK_DATA["#" + code.replace("#", "")];
    if (found) {
      setTrackResult({ ...found, code });
      setTrackError(false);
    } else {
      setTrackResult(null);
      setTrackError(true);
    }
    setShowTrackModal(true);
  }

  function doSearch() {
    const results = all.filter(tr =>
      (!searchFrom || tr.from.toLowerCase().includes(searchFrom.toLowerCase())) &&
      (!searchTo || tr.to.toLowerCase().includes(searchTo.toLowerCase()))
    );
    setSearchResults(results.length ? results : all);
    setActiveTab("search");
  }

  const prevSlide = () => setCarouselIndex(i => (i - 1 + sponsored.length) % sponsored.length);
  const nextSlide = () => setCarouselIndex(i => (i + 1) % sponsored.length);

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-green-900 via-green-800 to-green-900 p-4">
      {/* Phone Frame */}
      <div className="relative w-full max-w-sm bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col" style={{ height: 780, fontFamily: "'Segoe UI', sans-serif" }}>

        {/* STATUS BAR */}
        <div className="flex justify-between items-center px-5 pt-3 pb-1 bg-green-700 text-white text-xs font-medium">
          <span>9:41</span>
          <span className="font-bold tracking-wide text-sm">MON COLIS</span>
          <span>📶 🔋</span>
        </div>

        {/* SCROLLABLE CONTENT */}
        <div className="flex-1 overflow-y-auto bg-gray-50" style={{ scrollbarWidth: "none" }}>

          {/* ── HOME TAB ── */}
          {activeTab === "home" && (
            <div>
              {/* HERO HEADER */}
              <div className="relative bg-green-700 px-5 pt-4 pb-8 overflow-hidden">
                <div className="absolute inset-0 opacity-10" style={{ background: "repeating-linear-gradient(45deg, #fff 0, #fff 1px, transparent 0, transparent 50%)", backgroundSize: "12px 12px" }} />
                {/* Lang Selector */}
                <div className="flex justify-between items-center mb-4">
                  <button onClick={() => setShowLangPicker(!showLangPicker)} className="flex items-center gap-1 bg-white/20 rounded-full px-3 py-1.5 text-white text-xs font-semibold hover:bg-white/30 transition-all active:scale-95 backdrop-blur-sm">
                    <span className="text-base">{t.flag}</span>
                    <span>{t.name}</span>
                    <span className="ml-1">▾</span>
                  </button>
                  <div className="flex gap-1">
                    <button className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center text-white hover:bg-white/30 active:scale-95">🔔</button>
                    <button className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center text-white hover:bg-white/30 active:scale-95">👤</button>
                  </div>
                </div>

                {/* Lang Picker Dropdown */}
                {showLangPicker && (
                  <div className="absolute top-16 left-5 z-50 bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100" style={{ minWidth: 200 }}>
                    {Object.entries(LANGS).map(([k, v]) => (
                      <button key={k} onClick={() => { setLang(k); setShowLangPicker(false); }}
                        className={`w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-green-50 transition-colors ${lang === k ? "bg-green-50 font-bold text-green-700" : "text-gray-700"}`}>
                        <span className="text-xl">{v.flag}</span>
                        <span className="text-sm">{v.name}</span>
                        {lang === k && <span className="ml-auto text-green-600">✓</span>}
                      </button>
                    ))}
                  </div>
                )}

                <div className="text-white mb-1">
                  <div className="flex items-center gap-1">
                    <h1 className="text-2xl font-black tracking-tight">{t.tagline}</h1>
                    <VoiceBtn text={t.tagline} />
                  </div>
                  <p className="text-green-200 text-sm mt-0.5">{t.subtitle}</p>
                </div>

                {/* SEARCH BAR */}
                <div className="bg-white rounded-2xl shadow-lg mt-4 p-3 space-y-2">
                  <div className="flex items-center gap-2">
                    <span className="text-green-600 text-lg">🛫</span>
                    <input value={searchFrom} onChange={e => setSearchFrom(e.target.value)}
                      placeholder={t.searchFrom}
                      className="flex-1 text-sm text-gray-700 outline-none placeholder-gray-400 bg-transparent" />
                    <VoiceBtn text={t.searchFrom} small />
                  </div>
                  <div className="h-px bg-gray-100 mx-2" />
                  <div className="flex items-center gap-2">
                    <span className="text-red-600 text-lg">🛬</span>
                    <input value={searchTo} onChange={e => setSearchTo(e.target.value)}
                      placeholder={t.searchTo}
                      className="flex-1 text-sm text-gray-700 outline-none placeholder-gray-400 bg-transparent" />
                    <VoiceBtn text={t.searchTo} small />
                  </div>
                  <button onClick={doSearch}
                    className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2.5 rounded-xl text-sm active:scale-98 transition-all shadow-md flex items-center justify-center gap-2">
                    <span>🔍</span> {t.searchBtn}
                  </button>
                </div>
              </div>

              {/* TRACK SECTION */}
              <div className="mx-4 -mt-4 bg-white rounded-2xl shadow-md p-4 border border-yellow-200">
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-xl">📍</span>
                  <h2 className="font-bold text-gray-800 text-sm">{t.trackTitle}</h2>
                  <VoiceBtn text={t.trackTitle} small />
                </div>
                <div className="flex gap-2">
                  <input value={trackCode}
                    onChange={e => setTrackCode(e.target.value)}
                    onKeyDown={e => e.key === "Enter" && doTrack()}
                    placeholder={t.trackPlaceholder}
                    className="flex-1 border-2 border-yellow-300 focus:border-yellow-500 rounded-xl px-3 py-2.5 text-sm outline-none text-gray-700 placeholder-gray-400 bg-yellow-50" />
                  <button onClick={doTrack}
                    className="bg-yellow-400 hover:bg-yellow-500 text-green-900 font-bold px-4 py-2.5 rounded-xl text-sm active:scale-95 transition-all shadow">
                    {t.trackBtn}
                  </button>
                </div>
                <p className="text-xs text-gray-400 mt-2 text-center">Essayez: #MC-5580 · #MC-1234 · #MC-9999</p>
              </div>

              {/* URGENT DEPARTURES CAROUSEL */}
              <div className="mt-5 px-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-1">
                    <span className="text-base">🔥</span>
                    <h2 className="font-bold text-gray-800 text-sm">{t.urgentTitle}</h2>
                    <VoiceBtn text={t.urgentTitle} small />
                  </div>
                  <button onClick={() => { setSearchResults(all); setActiveTab("search"); }} className="text-xs text-green-600 font-semibold hover:underline">Tout voir →</button>
                </div>

                {/* Carousel */}
                <div className="relative">
                  <div className="overflow-hidden rounded-2xl">
                    {sponsored.map((tr, i) => (
                      <div key={tr.id} className={`transition-all duration-300 ${i === carouselIndex ? "block" : "hidden"}`}>
                        <div onClick={() => setSelectedTransporter(tr)}
                          className="relative rounded-2xl p-4 text-white cursor-pointer active:scale-98 transition-all shadow-lg"
                          style={{ background: `linear-gradient(135deg, ${tr.color}, ${tr.color}cc)` }}>
                          <div className="absolute top-3 right-3 bg-yellow-400 text-yellow-900 text-xs font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                            ⭐ {t.sponsored}
                          </div>
                          <div className="flex items-center gap-3 mb-3">
                            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center text-2xl">{tr.emoji}</div>
                            <div>
                              <h3 className="font-bold text-base">{tr.name}</h3>
                              <p className="text-white/80 text-xs">{tr.from} → {tr.to}</p>
                            </div>
                          </div>
                          <div className="flex gap-3 text-xs mb-3">
                            <span className="bg-white/20 rounded-lg px-2 py-1">📅 {tr.nextDep}</span>
                            <span className="bg-white/20 rounded-lg px-2 py-1">⚖️ {tr.price}€{t.perKg}</span>
                            <span className="bg-white/20 rounded-lg px-2 py-1">⭐ {tr.rating} ({tr.reviews})</span>
                          </div>
                          <div className="flex gap-1 flex-wrap">
                            {tr.services.map((s, idx) => <span key={idx} className="bg-white/15 text-xs rounded-full px-2 py-0.5">{s}</span>)}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <button onClick={prevSlide} className="w-8 h-8 bg-white rounded-full shadow flex items-center justify-center text-gray-600 hover:bg-gray-50 active:scale-95">‹</button>
                    <div className="flex gap-1">
                      {sponsored.map((_, i) => <div key={i} className={`w-2 h-2 rounded-full transition-all ${i === carouselIndex ? "bg-green-600 w-4" : "bg-gray-300"}`} />)}
                    </div>
                    <button onClick={nextSlide} className="w-8 h-8 bg-white rounded-full shadow flex items-center justify-center text-gray-600 hover:bg-gray-50 active:scale-95">›</button>
                  </div>
                </div>
              </div>

              {/* ALL TRANSPORTERS */}
              <div className="mt-5 px-4 pb-6">
                <h2 className="font-bold text-gray-800 text-sm mb-3">Tous les transporteurs</h2>
                <div className="space-y-3">
                  {all.filter(tr => !tr.sponsored).map(tr => (
                    <div key={tr.id} onClick={() => setSelectedTransporter(tr)}
                      className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex gap-3 cursor-pointer hover:border-green-300 active:scale-98 transition-all">
                      <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl" style={{ background: tr.color + "22" }}>{tr.emoji}</div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start">
                          <h3 className="font-bold text-gray-800 text-sm leading-tight">{tr.name}</h3>
                          <span className="text-green-600 font-bold text-sm ml-2">{tr.price}€{t.perKg}</span>
                        </div>
                        <p className="text-gray-500 text-xs mt-0.5">{tr.from} → {tr.to}</p>
                        <div className="flex gap-2 mt-1.5">
                          <span className="text-xs text-yellow-600 font-medium">⭐ {tr.rating}</span>
                          <span className="text-xs text-gray-400">({tr.reviews} avis)</span>
                          <span className="text-xs text-blue-500 ml-auto">📅 {tr.nextDep}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* ── SEARCH TAB ── */}
          {activeTab === "search" && (
            <div className="p-4">
              <div className="flex items-center gap-2 mb-4">
                <h2 className="font-bold text-gray-800 text-lg">{t.searchTitle}</h2>
                <VoiceBtn text={t.searchTitle} small />
              </div>
              <div className="bg-white rounded-2xl shadow-sm p-4 mb-4 border border-gray-100 space-y-3">
                <div>
                  <label className="text-xs font-semibold text-gray-500 mb-1 block">{t.searchFrom}</label>
                  <select value={searchFrom} onChange={e => setSearchFrom(e.target.value)}
                    className="w-full border-2 border-green-200 rounded-xl px-3 py-2 text-sm outline-none bg-green-50 text-gray-700">
                    <option value="">-- {t.searchFrom} --</option>
                    {t.cities_eu.map(c => <option key={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-gray-500 mb-1 block">{t.searchTo}</label>
                  <select value={searchTo} onChange={e => setSearchTo(e.target.value)}
                    className="w-full border-2 border-red-200 rounded-xl px-3 py-2 text-sm outline-none bg-red-50 text-gray-700">
                    <option value="">-- {t.searchTo} --</option>
                    {t.cities_ml.map(c => <option key={c}>{c}</option>)}
                  </select>
                </div>
                <button onClick={doSearch}
                  className="w-full bg-green-600 text-white font-bold py-3 rounded-xl text-sm active:scale-98 transition-all shadow-md flex items-center justify-center gap-2">
                  🔍 {t.searchBtn}
                </button>
              </div>
              {searchResults && (
                <div className="space-y-3">
                  {searchResults.map(tr => (
                    <div key={tr.id} onClick={() => setSelectedTransporter(tr)}
                      className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 cursor-pointer hover:border-green-300 active:scale-98 transition-all">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl" style={{ background: tr.color + "22" }}>{tr.emoji}</div>
                        <div className="flex-1">
                          <div className="flex justify-between">
                            <h3 className="font-bold text-gray-800 text-sm">{tr.name}</h3>
                            {tr.sponsored && <span className="bg-yellow-100 text-yellow-700 text-xs font-semibold px-2 py-0.5 rounded-full">⭐ {t.sponsored}</span>}
                          </div>
                          <p className="text-gray-500 text-xs">{tr.from} → {tr.to}</p>
                        </div>
                      </div>
                      <div className="flex gap-2 text-xs">
                        <span className="bg-green-50 text-green-700 rounded-lg px-2 py-1 font-bold">{tr.price}€{t.perKg}</span>
                        <span className="bg-gray-50 text-gray-600 rounded-lg px-2 py-1">⭐ {tr.rating}</span>
                        <span className="bg-blue-50 text-blue-600 rounded-lg px-2 py-1">📅 {tr.nextDep}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* ── NOTIFICATIONS TAB ── */}
          {activeTab === "notif" && (
            <div className="p-4">
              <div className="flex items-center gap-2 mb-4">
                <h2 className="font-bold text-gray-800 text-lg">{t.notifTitle}</h2>
                <VoiceBtn text={t.notifTitle} small />
              </div>
              <div className="space-y-3">
                {[
                  { icon: "📦", text: "Votre colis #MC-5580 est en transit", time: "Il y a 2h", color: "blue" },
                  { icon: "✅", text: "Colis #MC-1234 prêt pour retrait à Kayes", time: "Hier", color: "green" },
                  { icon: "🔥", text: "Mali Express: fermeture conteneur dans 3 jours!", time: "Il y a 1j", color: "red" },
                ].map((n, i) => (
                  <div key={i} className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex gap-3 items-start">
                    <div className={`w-10 h-10 rounded-xl bg-${n.color}-50 flex items-center justify-center text-xl flex-shrink-0`}>{n.icon}</div>
                    <div>
                      <p className="text-sm text-gray-800 font-medium">{n.text}</p>
                      <p className="text-xs text-gray-400 mt-1">{n.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* ── ACTIVITY TAB ── */}
          {activeTab === "activity" && (
            <div className="p-4">
              <div className="flex items-center gap-2 mb-4">
                <h2 className="font-bold text-gray-800 text-lg">{t.actTitle}</h2>
                <VoiceBtn text={t.actTitle} small />
              </div>
              <div className="space-y-3">
                {[
                  { code: "#MC-5580", tr: "Mali Express Cargo", step: 2, icon: "🚢" },
                  { code: "#MC-1234", tr: "Sahel Fret Milano", step: 4, icon: "✅" },
                ].map((a, i) => (
                  <div key={i} onClick={() => { setTrackCode(a.code); setTrackResult({ ...TRACK_DATA[a.code], code: a.code }); setTrackError(false); setShowTrackModal(true); }}
                    className="bg-white rounded-2xl p-4 shadow-sm border border-gray-100 cursor-pointer hover:border-green-300 active:scale-98 transition-all">
                    <div className="flex justify-between items-center mb-2">
                      <span className="font-mono font-bold text-green-700 text-sm">{a.code}</span>
                      <span className="text-lg">{a.icon}</span>
                    </div>
                    <p className="text-xs text-gray-500">{a.tr}</p>
                    <div className="mt-2 h-1.5 bg-gray-100 rounded-full">
                      <div className="h-1.5 bg-green-500 rounded-full" style={{ width: `${(a.step / 4) * 100}%` }} />
                    </div>
                    <p className="text-xs text-gray-400 mt-1">Étape {a.step}/4</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* BOTTOM NAVIGATION */}
        <div className="bg-white border-t border-gray-100 flex shadow-xl" style={{ paddingBottom: "env(safe-area-inset-bottom, 8px)" }}>
          {[
            { id: "home", icon: "🏠", label: t.navHome },
            { id: "search", icon: "🔍", label: t.navSearch },
            { id: "notif", icon: "🔔", label: t.navNotif },
            { id: "activity", icon: "📋", label: t.navActivity },
          ].map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className={`flex-1 flex flex-col items-center py-3 transition-all ${activeTab === tab.id ? "text-green-600" : "text-gray-400 hover:text-gray-600"}`}>
              <span className="text-xl">{tab.icon}</span>
              <span className={`text-xs mt-0.5 font-medium ${activeTab === tab.id ? "text-green-600" : ""}`}>{tab.label}</span>
              {activeTab === tab.id && <div className="w-1 h-1 bg-green-600 rounded-full mt-0.5" />}
            </button>
          ))}
        </div>

        {/* TRACKING MODAL */}
        {showTrackModal && (
          <div className="absolute inset-0 bg-black/50 flex items-end z-50 backdrop-blur-sm" onClick={() => setShowTrackModal(false)}>
            <div className="bg-white w-full rounded-t-3xl p-5 shadow-2xl max-h-[85%] overflow-y-auto" onClick={e => e.stopPropagation()}>
              {trackResult ? (
                <>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-black text-gray-800 text-lg">{t.trackResult}</h3>
                      <VoiceBtn text={t.trackResult} small />
                    </div>
                    <button onClick={() => setShowTrackModal(false)} className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-gray-600 hover:bg-gray-200 active:scale-95 font-bold">×</button>
                  </div>
                  <div className="inline-flex items-center gap-2 bg-green-50 rounded-xl px-3 py-1.5 mb-4">
                    <span className="font-mono font-bold text-green-700">{trackResult.code}</span>
                    <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${trackResult.step === 4 ? "bg-green-600 text-white" : "bg-yellow-400 text-yellow-900"}`}>
                      {trackResult.step === 4 ? "✅ Livré" : "🔄 En cours"}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 mb-4">
                    {[
                      { icon: "🚛", label: "Transporteur", val: trackResult.transporter },
                      { icon: "📅", label: "Date", val: trackResult.date },
                      { icon: "🛫", label: t.from, val: trackResult.from },
                      { icon: "🛬", label: t.to, val: trackResult.to },
                      { icon: "⚖️", label: "Poids", val: trackResult.weight },
                      { icon: "📊", label: "Étape", val: `${trackResult.step} / 4` },
                    ].map((row, i) => (
                      <div key={i} className="bg-gray-50 rounded-xl p-2.5">
                        <div className="text-xs text-gray-400 mb-0.5">{row.icon} {row.label}</div>
                        <div className="text-sm font-bold text-gray-800">{row.val}</div>
                      </div>
                    ))}
                  </div>
                  <StepBar step={trackResult.step} t={t} />
                  <button onClick={() => setShowTrackModal(false)} className="mt-4 w-full bg-green-600 text-white font-bold py-3 rounded-xl active:scale-98 transition-all">
                    {t.close}
                  </button>
                </>
              ) : (
                <div className="text-center py-6">
                  <div className="text-5xl mb-3">❓</div>
                  <h3 className="font-bold text-gray-800 text-lg mb-2">Code introuvable</h3>
                  <p className="text-gray-500 text-sm mb-4">Vérifiez le code et réessayez.<br />Essayez: <span className="font-mono text-green-600">#MC-5580</span></p>
                  <button onClick={() => setShowTrackModal(false)} className="bg-gray-100 text-gray-700 font-bold px-8 py-3 rounded-xl active:scale-95">
                    {t.close}
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* TRANSPORTER PROFILE MODAL */}
        {selectedTransporter && (
          <div className="absolute inset-0 bg-black/50 flex items-end z-50 backdrop-blur-sm" onClick={() => setSelectedTransporter(null)}>
            <div className="bg-white w-full rounded-t-3xl shadow-2xl max-h-[90%] overflow-y-auto" onClick={e => e.stopPropagation()}>
              <div className="h-24 flex items-center justify-center text-5xl relative" style={{ background: `linear-gradient(135deg, ${selectedTransporter.color}, ${selectedTransporter.color}99)` }}>
                {selectedTransporter.emoji}
                <button onClick={() => setSelectedTransporter(null)} className="absolute top-3 right-3 w-8 h-8 bg-white/20 rounded-full flex items-center justify-center text-white font-bold hover:bg-white/30 active:scale-95">×</button>
                {selectedTransporter.sponsored && (
                  <div className="absolute top-3 left-3 bg-yellow-400 text-yellow-900 text-xs font-bold px-2 py-0.5 rounded-full">⭐ {t.sponsored}</div>
                )}
              </div>
              <div className="p-5">
                <div className="flex items-start justify-between mb-1">
                  <h2 className="font-black text-gray-800 text-xl">{selectedTransporter.name}</h2>
                  <VoiceBtn text={selectedTransporter.name} />
                </div>
                <div className="flex items-center gap-2 mb-4">
                  <span className="text-yellow-500 font-bold">⭐ {selectedTransporter.rating}</span>
                  <span className="text-gray-400 text-sm">({selectedTransporter.reviews} avis)</span>
                </div>
                <div className="grid grid-cols-2 gap-3 mb-4">
                  {[
                    { icon: "🛫", label: t.from, val: selectedTransporter.from },
                    { icon: "🛬", label: t.to, val: selectedTransporter.to },
                    { icon: "💰", label: "Tarif", val: selectedTransporter.price + "€/kg" },
                    { icon: "📅", label: "Prochain départ", val: selectedTransporter.nextDep },
                  ].map((row, i) => (
                    <div key={i} className="bg-gray-50 rounded-xl p-3">
                      <div className="text-xs text-gray-400">{row.icon} {row.label}</div>
                      <div className="font-bold text-gray-800 text-sm mt-0.5">{row.val}</div>
                    </div>
                  ))}
                </div>
                <div className="mb-4">
                  <p className="text-xs font-semibold text-gray-500 mb-2">Services proposés</p>
                  <div className="flex gap-2 flex-wrap">
                    {selectedTransporter.services.map((s, i) => <span key={i} className="bg-green-50 text-green-700 text-sm rounded-full px-3 py-1 font-medium">{s}</span>)}
                  </div>
                </div>
                <button className="w-full bg-green-600 text-white font-bold py-3.5 rounded-xl active:scale-98 transition-all shadow-md text-sm flex items-center justify-center gap-2 mb-2">
                  📩 Contacter le Transporteur
                </button>
                <button className="w-full bg-yellow-400 text-yellow-900 font-bold py-3 rounded-xl active:scale-98 transition-all text-sm flex items-center justify-center gap-2">
                  📦 Réserver une place
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Mali flag stripe at bottom */}
        <div className="absolute bottom-0 left-0 right-0 h-0.5 flex pointer-events-none" style={{ zIndex: 60 }}>
          <div className="flex-1 bg-green-600" /><div className="flex-1 bg-yellow-400" /><div className="flex-1 bg-red-600" />
        </div>
      </div>
    </div>
  );
}
